# Ask the user for cities they have visited.
prompt = ("Enter the name of a city you've visited."
          '\nType "quit" to leave. ')

while True:
    city = input(prompt)

    if city == "quit":
        break

    print(f"{city.title()} sounds lovely.\n")