# Get a user's name and greet them.
name = input("What is your name? ")
print(f"I am {name.title()}, King of the Britons.")

prompt = """This is an extremely long-winded prompt.
It goes on for several lines.

Like so.

But because this a variable, I can easily put it inside of an input call.

Input something: """

message = input(prompt)

print(f"And your message is... {message}")