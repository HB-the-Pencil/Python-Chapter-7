# Remove a specific type of pet from the list.
pets = ["dog", "cat", "gerbil", "mouse", "hamster", "cat", "hamster",
        "gerbil", "dog", "mouse", "bird", "dog", "cat", "bird"]
print(pets)

remove_pet = input("What kind of pet do you not want? ")

while remove_pet in pets:
    pets.remove(remove_pet)

print(pets)
