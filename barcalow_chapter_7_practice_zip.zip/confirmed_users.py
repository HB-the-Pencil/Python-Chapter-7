from grammar_library import punctuate_list

# Make a list of users who haven't been verified and one of users who have.
unconfirmed_users = ["parzival", "art3mis", "aech", "daito", "shoto"]
confirmed_users = ["anorak", "the great and powerful og"]

# While there are unconfirmed users, move users to the confirmed users list.
while unconfirmed_users:
    user = unconfirmed_users.pop()
    print(f"{user.title()} is being verified.")
    print("...")
    confirmed_users.append(user)
    print(f"{user.title()} has been verified.\n")

# Print out a punctuated list. I learned try-except for this!
try:
    print("The following users have been verified:",
          punctuate_list(confirmed_users, True))
except NameError:
    print("Grammar library not imported properly.")
    print("The following users have been verified:")
    for user in confirmed_users:
        print(f"\t{user.title()}")
