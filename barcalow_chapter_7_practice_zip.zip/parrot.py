# Echo a message from the user.
prompt = "Squawk! Teach Polly a phrase. Say goodbye to leave. "

flag = True
while flag:
    message = input(prompt)
    if message == "goodbye":
        flag = False
    else:
        print(f"{message[:1].title()}{message[1:]}!")