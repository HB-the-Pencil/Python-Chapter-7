# Tell whether an inputted number is even or odd.
num = int(input("Enter a number to check if it's even or odd. "))
print()

if num % 2 == 0:
    print(f"{num} is even.")
else:
    print(f"{num} is odd.")
print("(You needed a program to check this?)")