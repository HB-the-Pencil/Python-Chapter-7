# Count up in a loop from 0 to 10 (inclusive).
number = 0

while number < 10:
    number += 1
    if number % 2 == 0:
        continue

    print(number)
