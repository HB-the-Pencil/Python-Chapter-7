# See if a user is tall enough to ride a rollercoaster (min height is 4 feet).
height = int(input("How tall are you (in inches)? "))

if height >= 48:
    print("\nYou may ride the Death Weasel.")
else:
    print("\nYou're too small to ride the Death Weasel."
          "\nThat's probably a good thing.")