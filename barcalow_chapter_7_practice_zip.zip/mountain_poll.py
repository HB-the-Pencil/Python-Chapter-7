# Poll users for mountains that they want to climb someday.
responses = {}

polling = True

while polling:
    # Get the info.
    name = input("What's your name? ")
    mountain = input("What mountain do you want to climb someday? ")

    # Put the info in the dictionary.
    responses[name] = mountain

    # Continue the poll.
    y_n = input("Would you like to add another response? (y/n) ")
    if y_n == "n":
        polling = False
    print()

# The results of the poll.
print("The results of the poll:")
for name, mountain in responses.items():
    print(f"{name.title()} would like to climb {mountain.title()}.")